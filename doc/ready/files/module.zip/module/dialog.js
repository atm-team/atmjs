define('./dialog.js', ['./util.js'], function (require, exports, module) {
    var util = require('./util.js');
    module.exports = {
        show: function () {
            // do something
            util.log('dialog is opened');
            // do something else
        }
    }
});