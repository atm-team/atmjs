var define;
var parser = {};
(function () {
    var modules = {};
    var defines = {}
    define = function (id, deps, factory) {
        defines[id] = {
            id: id,
            deps: deps,
            factory: factory
        };
    };

    function require (id) {
        if (modules[id]) {
            return modules[id].exports;
        } else {
            var module = {
                exports: {}
            };
            modules[id] = module;
            var factory = defines[id].factory;
            factory.apply(module.exports, [require, module.exports, module]);
            return module.exports;
        }
    }
    parser.use = function(id, callback) {
        callback && callback(require(id));
    }
})();