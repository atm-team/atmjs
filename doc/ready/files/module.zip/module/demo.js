define('./demo.js', ['./util.js', './dialog.js'], function (require, exports, module) {
    var dialog = require('./dialog.js');
    module.exports = {
        init: function () {
            // do something
            dialog.show();
            // do something else
        }
    }
});