define('./util.js', [], function (require, exports, module) {
    module.exports = {
        log: function (str) {
            console.log(str);
        }
    }
});